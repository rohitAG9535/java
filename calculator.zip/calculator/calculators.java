package calculator;

import java.util.Scanner;

public class calculators {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number");
		int s1 = sc.nextInt();
		System.out.println("Enter the second number");
		int s2 = sc.nextInt();
		System.out.println(s1+s2);
		System.out.println(s1-s2);
		System.out.println(s1*s2);
		System.out.println(s1/s2);
		
	

	}

}
